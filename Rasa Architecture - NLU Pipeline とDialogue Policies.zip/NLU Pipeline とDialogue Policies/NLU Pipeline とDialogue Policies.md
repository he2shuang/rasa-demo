Rasaはエージェントを介して他の各モジュールと連携します。最も簡単な使用シーンは、ユーザーが入力テキストを入力すると、エージェントはまずNLU Pipelineモジュールを使用して入力テキストを分解し、ユーザーの意図を理解します。その後、Dialogue Policiesを用いてユーザーの意図に基づいてRasaが次に実行すべき行動を予測し、最終的にエージェントがユーザーに応答を返します。

![[Pasted Image 20250912105721_340.png]]


## NLU Pipeline

意図分類、エンティティ抽出を処理する。

### NLU Pipelineの設定：

`confing.yml`ファイルで設定され、主に以下の4つがあります。
- Tokenizers
- Featurizers
- Intent Classifiers
- Entity Extractors
![[pipeline.webp]]
![[Pasted image 20250916181016.png]]
#### Tokenizer(単語分割器)
ユーザーが入力した文章を、モデルが処理できる最小単位（トークン、通常は単語や文字）に分割する。

![[tokeniser.webp]]

Rasaパイプラインの最初のステップは、発話をトークンと呼ばれる小さなテキストの塊に分割することです。これは機械学習のためにテキストを特徴量化（フィーチャライズ）する前に実行される必要があるため、通常、トークナイザーがパイプラインの最初に配置されます。

#### Featurizer(特徴化器)
トークナイザーによって分割されたトークンを、機械学習モデルが理解できる数値ベクトル（特徴量）に変換するコンポーネントです

![[Pasted image 20250805101359.png]]

Rasaはこれらの特徴量生成器を全てのトークンに適用しますが、同時に文全体に対する特徴量も生成します。これは`CLS`特徴量または文特徴量とも呼ばれることがあります。

![[Pasted image 20250805101749.png]]

従来、トークン特徴はエンティティ抽出に、文特徴は意図検出に使用されてきた。RasaのDIETアルゴリズム導入によりこの状況は変化したが、当初の設計意図を理解しておくことは有益である。

#### Intent Classifier(意図分類器)
ユーザーの入力文全体が、どのような「意図 (Intent)」を持っているか（例：「挨拶」「質問」「注文」など）を分類するモデルです

すべてのトークンと文全体に対して特徴量を生成したら、それを意図分類モデルに渡すことができます。意図分類とエンティティ抽出の両方を処理できるRasaのDIETモデルの使用をお勧めします。このモデルはトークン特徴量と文特徴量の両方から学習することが可能です。

![[Pasted image 20250805101841.png]]

#### Entity Extractors(エンティティ抽出器)
文章の中から特定の情報を持つ固まり（エンティティ）、例えば日付、地名、人名、品名などを探し出して抽出するコンポーネントです。

DIETはエンティティ検出を学習可能ですが、あらゆる種類のエンティティに必ずしも推奨されるわけではありません。例えば電話番号のように構造化されたパターンに従うエンティティは、検出にアルゴリズムを必要としません。代わりに [RegexEntityExtractor](https://rasa.com/docs/rasa/components/#regexentityextractor) で処理できます。また、ユースケースに合致する場合は[DucklingEntityExtractor](https://rasa.com/docs/rasa/components/#ducklingentityextractor)や[SpacyEntityExtractor](https://rasa.com/docs/rasa/components/#spacyentityextractor)の追加も検討してください。

![[Pasted image 20250805101923.png]]
## Dialogue Policies

文脈に基づいて会話の次の行動を決定する。

Rasaがアクションを予測する際、現在の意図やエンティティだけを見るわけではありません。これまでの会話全体も考慮に入れます。

![[Pasted image 20250805102300.png]]

### Dialogue Policiesの設定：

`confing.yml`ファイルで設定され、主に以下の3つがあります。

- RulePolicy
- MemoizationPolicy
- TEDPolicy

これらのポリシーはすべて、並行して次のアクションを予測し、最も確信度の高いポリシーが次のアクションを決定します。2つのポリシーの確信度が同等の場合、Rasaは決定を処理するための優先順位付けメカニズムを備えています。`RulePolicy`が最上位の優先度を持ち、`MemoizationPolicy`が次位、`TEDPolicy`が最下位の優先度となる。

#### RulePolicy

`rules.yml` ファイルに記述された、固定の「ルール（規則）」に基づいて次に行うアクションを決定するポリシーです。例えば、「ユーザーが『こんにちは』と言ったら、必ず『こんにちは！』と返す」といったルールを扱います。

このポリシーは、`rules.yml`ファイル内のルール定義を確認し、それらを適用します。以下にそのようなルールの例を示します。

```yaml
- rule: Say hi anytime the user says hi
  steps:
  - intent: greet
  - action: utter_greet
```
#### MemoizationPolicy

このポリシーは、現在の対話がトレーニングデータ内のいずれかのストーリー（`stories.yml`ファイルに記述された）と一致するかどうかを検査します。完全に一致する状況に遭遇した場合、機械学習による予測は行わず、代わりに一致したストーリーに基づいて次の行動を直接予測します。

例えば。もしこれがこれまでの話だとすれば。

```yaml
steps:
- intent: greet
- action: utter_greet
- intent: check_balance
```

次に、このストーリーで学習された場合、メモ化ポリシーが機能するようになるでしょう。

```yaml
stories:
- story: check account balance
  steps:  
  - intent: greet  
  - action: utter_greet  
  - intent: check_balance  
  - action: utter_ask_userid  
  - intent: inform    
    entities:
userid: “1234”  
  - action: check_balance  
  - intent: thanks  
  - action: utter_goodbye
```

この場合、`MemoizationPolicy`は次のアクションとして`utter_ask_userid`を予測する。

#### TEDPolicy

`Transformer Embedding Dialogue Policy` の略です。`Transformer`という最新のアーキテクチャを利用して、対話の文脈を理解し、次にどのアクションを実行すべきかを予測する、Rasaの主要な機械学習ベースのポリシーです

トランスフォーマー埋め込み対話（TED）ポリシーは、次の行動予測のためのマルチタスクアーキテクチャです。現在の会話ターンと過去のターンの一部から特徴量を抽出し、次に取るべき行動を予測します。詳細については、[論文](https://arxiv.org/abs/1910.00486)および[YouTubeチャンネル](https://www.youtube.com/watch?v=j90NvurJI4I)で詳しく解説しています。
  
一般的に、初期段階ではハイパーパラメータの調整は推奨しません。なぜなら、代表的なトレーニングセットの取得が最優先事項だからです。ただし、適切なトレーニングセットが揃った後は、`TEDPolicy`コンポーネントの`max_history`パラメータを調整することが有効となる場合があります。

```yaml
policies:
  - name: TEDPolicy    
    max_history: 5    
    epochs: 200
```

文脈が非常に重要な複雑な会話を行う場合、`max_history`パラメータを増加させるのが適切かもしれません。ただし、`max_history`パラメータを高く設定すると、モデルの学習時間が長くなる可能性があることに注意してください。

## 実際の応用

次に、`Dialogue Policies`の内容を変更し、`RulePolicy`のみを残します。変更前後のRasaの応答の変化を確認しましょう。

### NLU データ 
![[Pasted Image 20250916112618_778.png]]
![[Pasted Image 20250916112745_402.png]]
![[Pasted Image 20250916135615_173.png]]
### config
![[Pasted Image 20250916094621_343.png]]
![[Pasted Image 20250916094745_412.png]]

### 変更前
![[Pasted Image 20250916094745_412.png]]

`rasa train` でトレーニングを実施

`Rule Policy`、`MemoizationPolicy`、`TEDPolicy`がロードされているのが見える

![[Pasted Image 20250916111456_451.png]]


`rasa shell` でテストを実施

ユーザーが「hi」「hello」「bye」を送信すると、Rasaは正常に応答します

![[Pasted Image 20250916111805_757.png]]


### 変更後
![[Pasted Image 20250916140717_297.png]]

`rasa train` でトレーニングを実施

`RulePolicy`のみがロードされているのが見える

![[Pasted Image 20250916112002_950.png]]

`rasa shell` でテストを実施

Rasaはユーザーが送信した「bye」にのみ応答でき、「hi」「hello」が送信された場合、次に何をすべきかわからず、一切応答しません

![[Pasted Image 20250916112145_443.png]]

### 原因の説明

`rules.yml`ファイルには次のようなルールがあります。ユーザーが「bye」と言った場合、Rasaは必ず「bye」と返信しなければなりません。

![[Pasted Image 20250916112618_778.png]]

`stories.yml`ファイルには次のようなストーリーがあります。ユーザーが挨拶した場合、Rasaもユーザーに挨拶します。

![[Pasted Image 20250916112745_402.png]]

* `Dialogue Policies`内の内容には、`RulePolicy`、`MemoizationPolicy`、`TEDPolicy`が存在する場合、Rasaはrules.ymlとstories.ymlの両方の内容を同時に使用します。したがって、ユーザーが「hi」「hello」「bye」を送信すると、Rasaは正常に応答します

* `RulePolicy`のみを保持している場合、Rasaは`rules.yml`のルールのみを使用し、`stories.yml`のストーリーは使用しません。そのため、Rasaはユーザーが送信した「bye」にのみ応答でき、「hi」「hello」が送信された場合、次に何をすべきかわからず、一切応答しません

## リンク

- [Detailed Blogpost on Non-English tools](https://rasa.com/blog/non-english-tools-for-rasa/)
- [Detailed Blogpost on NLU Pipelines](https://rasa.com/blog/intents-entities-understanding-the-rasa-nlu-pipeline/)
- [Detailed Blogpost on Dialogue Policies](https://rasa.com/blog/dialogue-policies-rasa-2/)
- [Rasa Config Components Documentation](https://rasa.com/docs/rasa/components/)
- [Examples of Custom Components](https://github.com/RasaHQ/rasa-nlu-examples)
- [Pipelines and Policies – Rasa Learning Center](https://learning.rasa.com/archive/conversational-ai-with-rasa/pipeline/)