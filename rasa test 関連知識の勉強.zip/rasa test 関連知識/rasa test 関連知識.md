
### データの検証とストーリー

データ検証は、**ドメイン、NLUデータ、またはストーリーデータにエラーや重大な不整合がないか**を検証します。例えば、同じトレーニングデータが2つの異なるインテントに存在する場合、同じ対話履歴が後続で異なるアクションを予測する場合、ストーリーで使用されているインテントがドメインで宣言されていない場合などです。
データを検証するには、CIに以下のコマンドを実行させます：

```
rasa data validate
```

>[!note]
> `rasa data validate` の実行は、お使いのルールがストーリーと整合しているかをテスト**しません**。ただし、トレーニング中に`RulePolicy`はルールとストーリー間の競合をチェックします。そのような競合が発生した場合、トレーニングは中止されます。

バリデータと利用可能なすべてのオプションについての詳細は、[`rasa data validate` のドキュメント](https://legacy-docs-oss.rasa.com/docs/rasa/command-line-interface#rasa-data-validate)を参照してください。

### テストストーリーの作成

トレーニング済みのモデルをテストストーリーでテストすることは、アシスタントが特定の状況でどのように振る舞うかについて確信を得るための最良の方法です。テストストーリーは、修正されたストーリー形式で記述され、完全な対話を提供し、特定のユーザー入力が与えられた場合にモデルが期待通りに動作することをテストできます。これは、ユーザーとの対話からより複雑なストーリーを導入し始める際に特に重要です。

テストシナリオはトレーニングデータ内のストーリーに似ていますが、ユーザーメッセージも含まれます。以下は`tests/test_stories.yml`の例です：

```yaml
stories:
- story: A basic story test
  steps:
  - user: |
      hello
    intent: greet
  - action: utter_ask_howcanhelp
  - user: |
     show me [chinese]{"entity": "cuisine"} restaurants
    intent: inform
  - action: utter_ask_location
  - user: |
      in [Paris]{"entity": "location"}
    intent: inform
  - action: utter_ask_price

```

以下のコマンドを実行して、アシスタントをテストできます：

```
rasa test
```

デフォルトでは、このコマンドは名前が `test_` で始まるファイル内のストーリーに対してテストを実行します。`--stories` パラメータを使用して、特定のテストストーリーファイルまたはディレクトリを指定することもできます。その他の設定オプションについては、[`rasa test` のCLIドキュメント](https://legacy-docs-oss.rasa.com/docs/rasa/command-line-interface#rasa-test)を参照してください。テスト結果の解釈については、後述の[[#テスト出力の解釈]]を参照してください。

### NLUモデルのみをテストする

ストーリーのテストに加えて、自然言語理解（NLU）モデルを単独でテストすることもできます。アシスタントを実環境にデプロイすると、トレーニングデータに含まれていないメッセージを処理することになります。これをシミュレートするために、常にデータの一部をテスト用に確保しておくべきです。例えば、`test/nlu.yml` にテストデータを記述します：

```yaml
version: "3.1"
nlu:

# --- send_money インテントのテスト ---
- intent: send_money
  examples: |
    # ケース1: 未見のエンティティ「佐藤」。これは汎化能力をテストする鍵である。
    - [佐藤](recipient)さんに[五千円](amount)を送りたい
    
    # ケース2: 未見のエンティティ「鈴木」と金額の不同表达「一万円」。
    - [鈴木](recipient)へ[一万円](amount)の送金をお願いします
    
    # ケース3: 異なる文型構造「〜への送金」。文法理解を試す。
    - [渡辺](recipient)さんへの[3000円](amount)の送金は可能ですか？
    
    # ケース4: 実体の順序を逆転させる。
    - [二千円](amount)を[中村](recipient)さんに振り込んでください
    
    # ケース5: 少し口語的でシンプルな表現。
    - [高橋](recipient)に[100円](amount)送って
    
    # ケース6: ユーザーが誤った情報を入力しました
    - 東京に[3000円](amount)を送りたい
    - 東京さんに[3000円](amount)を送りたい
    - 1000に[3000円](amount)を送りたい
    - [山田さん](recipient)に銀座を送金したい
    - 誰かに[3000円](amount)を送りたい

# --- 混同を招く可能性のある文を追加する（ネガティブサンプル）---
- intent: greet
  examples: |
    # ケース7: モデルが挨拶文で意図やエンティティを認識するかどうかを確認する。
    - こんにちは、鈴木さん
    - いつもお世話になっております
```

次に、以下のコマンドを使用してNLUモデルをテストします。ここで、`--model`は使用するモデルを設定し、`--nlu`は使用するテストデータの場所を指定し、`--out`は結果の保存場所を設定します。その他の設定オプションについては、[`rasa test` のCLIドキュメント](https://legacy-docs-oss.rasa.com/docs/rasa/command-line-interface#rasa-test)を参照してください。

```
rasa test nlu --model models/nlu_base --nlu tests/nlu.yml --out results/base_results
```

上記のコマンドを実行すると、プロジェクトの `results` フォルダ内に `base_results` というフォルダが生成され、その中にNLUモデルのテスト結果が格納されます。これらのテスト結果の解釈については、後述の[[#テスト出力の解釈]]を参照してください。

```
├── results
│   ├── base_results
│   │   ├── DIETClassifier_confusion_matrix.png
│   │   ├── DIETClassifier_errors.json
│   │   ├── DIETClassifier_histogram.png
│   │   ├── DIETClassifier_report.json
│   │   ├── intent_confusion_matrix.png
│   │   ├── intent_errors.json
│   │   ├── intent_histogram.png
│   │   └── intent_report.json
└── tests
    ├── nlu.yml
    └── test_stories.yml
```

もし自分でテストデータを個別に作成したくない場合は、以下の方法でトレーニングデータの一部をテストデータとして分割することができます：
- ホールドアウトテストセットを使用する
- クロスバリデーションを使用する
以下で、これら2つの方法の使用法を説明します。

##### ホールドアウトテストセットを使用する
train-test分割アプローチを使用する場合、時代遅れになりやすい静的なNLUテストセットを使用する代わりに、モデルを評価するたびに `rasa data split` を使用して[データをシャッフルして分割する](https://legacy-docs-oss.rasa.com/docs/rasa/command-line-interface#rasa-data-split)ことが最善です。以下の方法でNLUデータをトレーニングセットとテストセットに分割できます：

```
rasa data split nlu
```

上記のコマンドを実行すると、プロジェクト内に`train_test_split`というフォルダが生成され、その中に分割後のデータが格納されます。デフォルトでは、トレーニング/テストデータは80/20の割合で作成されます。

```
├── tests
│   ├── nlu.yml
│   └── test_stories.yml
└── train_test_split
    ├── nlg_test_data.yml
    ├── nlg_training_data.yml
    ├── test_data.yml
    └── training_data.yml
```

次に、以下の方法で、トレーニングされたNLUモデルが生成されたテストセット内のデータをどれだけうまく予測できるかを確認できます：
```
rasa test nlu \
    --nlu train_test_split/test_data.yml
```

##### クロスバリデーションを使用する

NLUトレーニングデータに大幅な変更（例：1つのインテントを2つに分割する、多数のトレーニング例を追加するなど）を加えた場合は、クロスバリデーションを使用して完全なNLU評価を実行すべきです。クロスバリデーションは、自動的に複数のトレーニング/テスト分割を作成し、各分割の評価結果を平均化します。これにより、すべてのデータがクロスバリデーション中に評価されるため、NLUモデルを自動的にテストする最も徹底的な方法となります。

クロスバリデーションモードでNLUテストを実行するには、以下を実行します：
```
rasa test nlu \
    --nlu data/nlu \
    --cross-validation
```

上記のコマンドを実行すると、プロジェクトの `results` フォルダにNLUモデルのテスト結果が生成されます。これらのテスト結果の解釈については、後述の[[#テスト出力の解釈]]を参照してください。

```
├── results
│   ├── DIETClassifier_confusion_matrix.png
│   ├── DIETClassifier_histogram.png
│   ├── DIETClassifier_report.json
│   ├── intent_confusion_matrix.png
│   ├── intent_errors.json
│   ├── intent_histogram.png
│   └── intent_report.json
```

`-f/--folds` フラグを使用して、使用するテスト/トレーニング分割の数を指定できます：

```
rasa test nlu \
    --nlu data/nlu \
    --cross-validation \
    --folds 5
```

>[!note]
>クロスバリデーション中、NLUモデルは各フォールドごとにトレーニングされるため、大規模なデータセットや多数のフォールドを使用するクロスバリデーションは非常に時間がかかる可能性があります。小規模なデータセットでは、多数のフォールドを指定すると、各テスト分割で利用可能なインテントごとの例が少なすぎる可能性があります。
>一方、指定するフォールド数が少ない場合、データはより大きな塊に分割され、各フォールドでトレーニングに必要なデータは比例して少なくなります。
>データセットサイズのこれら2つの考慮事項のバランスを取るために、適切なフォールド数を選択する必要があります。
>モデルをさらに改善するには、この [ハイパーパラメータチューニングのチュートリアル](https://blog.rasa.com/rasa-nlu-in-depth-part-3-hyperparameters/) をご覧ください。

#### NLUパイプラインの比較

トレーニングデータを最大限に活用するには、異なるパイプラインと異なる量のトレーニングデータでモデルをトレーニングし、評価する必要があります。そのためには、`rasa test` コマンドに複数の設定ファイルを渡します：

```
rasa test nlu --nlu data/nlu.yml \
   --config config_1.yml config_2.yml
```

これにより、いくつかのステップが実行されます：
1.  `data/nlu.yml` に基づいて、全体で80%のトレーニング/20%のテスト分割を作成します。
2.  全体のトレーニング部分から特定の割合のデータを除外します。
3.  残りのトレーニングデータに基づいて、各設定のモデルをトレーニングします。
4.  全体のテスト分割で各モデルを評価します。

ステップ2では、トレーニングデータ量を増やしたときに各パイプラインがどのように振る舞うかを理解するために、異なる割合のトレーニングデータで上記プロセスが繰り返されます。トレーニングは完全に決定論的ではないため、指定された各設定に対して、プロセス全体が3回繰り返されます。

すべての実行のf1スコアの平均と標準偏差がプロットされます。f1スコアのグラフは、すべてのトレーニング/テストセット、トレーニング済みモデル、分類レポート、エラーレポートとともに、`nlu_comparison_results`という名前のフォルダに保存されます。

f1スコアのグラフを調べることで、NLUモデルが十分なデータを持っているかどうかを理解するのに役立ちます。グラフが、すべてのトレーニングデータを使用してもf1スコアがまだ向上し続けていることを示している場合、データ量が増えるにつれてさらに改善する可能性があります。しかし、すべてのトレーニングデータを使用してもf1スコアがすでに横ばいになっている場合、データを追加しても効果は薄いかもしれません。これらのテスト結果の解釈については、後述の[[#テスト出力の解釈]]を参照してください。

実行回数や除外する割合を変更したい場合は、次のようにします：

```
rasa test nlu --nlu data/nlu.yml \
  --config config_1.yml config_2.yml \
  --runs 4 --percentages 0 25 50 70 90
```

#### テスト出力の解釈

##### Intent Classifiers

`rasa test` スクリプトは、インテント分類モデルに対してレポート（`intent_report.json`）、混同行列（`intent_confusion_matrix.png`）、信頼度のヒストグラム（`intent_histogram.png`）を生成します。

レポートは、各インテントの[precision](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.precision_score.html)、[recall](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.recall_score.html)、[f1_score](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.f1_score.html)、および全体の平均を記録します。`--report` パラメータを使用して、これらのレポートをJSONファイルとして保存できます。

```json
##### intent_report.json
{
 "cancel_transfers": {
   "precision": 1.0,
   "recall": 1.0,
   "f1-score": 1.0,
   "support": 9,
   "confused_with": {}
 },
 "transfer_money": {
   "precision": 1.0,
   "recall": 1.0,
   "f1-score": 1.0,
   "support": 13,
   "confused_with": {}
 },
 "affirm": {
   "precision": 1.0,
   "recall": 0.8,
   "f1-score": 0.888888888888889,
   "support": 5,
   "confused_with": {
     "retry_transfer": 1
   }
 },
 "retry_transfer": {
   "precision": 0.8571428571428571,
   "recall": 1.0,
   "f1-score": 0.923076923076923,
   "support": 6,
   "confused_with": {}
 },
 "deny": {
   "precision": 1.0,
   "recall": 1.0,
   "f1-score": 1.0,
   "support": 7,
   "confused_with": {}
 },
 "inform": {
   "precision": 1.0,
   "recall": 1.0,
   "f1-score": 1.0,
   "support": 12,
   "confused_with": {}
 },
 "accuracy": 0.9807692307692307,
 "macro avg": {
   "precision": 0.9761904761904763,
   "recall": 0.9666666666666667,
   "f1-score": 0.9686609686609686,
   "support": 52
 },
 "weighted avg": {
   "precision": 0.9835164835164835,
   "recall": 0.9807692307692307,
   "f1-score": 0.9804404996712689,
   "support": 52
 },
 "micro avg": {
   "precision": 0.9807692307692307,
   "recall": 0.9807692307692307,
   "f1-score": 0.9807692307692307,
   "support": 52
 }
}
```

混同行列は、どのインテントが他のインテントと誤認識されたかを示します。誤って予測されたすべてのサンプルは記録され、`errors.json` という名前のファイルに保存されるため、デバッグが容易になります。
![[Pasted image 20251022152541.png]]

```json
## errors.json
[
  {
    "text": "もちろん",
    "intent": "affirm",
    "intent_prediction": {
      "name": "retry_transfer",
      "confidence": 0.49688586592674255
    }
  }
]
```
ヒストグラムを使用すると、すべての予測の信頼度を視覚的に表示できます。正解の予測と不正解の予測は、それぞれ青と赤のバーで表示されます。トレーニングデータの質を向上させると、青いヒストグラムのバーがグラフの上方に移動し、赤いヒストグラムのバーが下方に移動します。これは、赤いヒストグラムのバーの数を減らすのにも役立ちます。
![[Pasted image 20251022152642.png]]

##### Response Selectors

`rasa test` は、レスポンスセレクタをインテント分類器と同じ方法で評価し、レポート（`response_selection_report.json`）、混同行列（`response_selection_confusion_matrix.png`）、信頼度のヒストグラム（`response_selection_histogram.png`）、エラー（`response_selection_errors.json`）を生成します。パイプラインに複数のレスポンスセレクタが含まれている場合、それらは単一のレポートで評価されます。
このレポートは、[リトリーバルインテント](https://legacy-docs-oss.rasa.com/docs/rasa/glossary#retrieval-intent)内の各サブインテントの適合率、再現率、f1スコアを記録し、全体の平均も提供します。`--report` パラメータを使用して、これらのレポートをJSONファイルとして保存できます。

##### Entity Extraction

`rasa test` は、トレーニング可能なエンティティ抽出器が認識した各エンティティタイプの再現率（recall）、適合率（precision）、f1スコア（f1_score）を報告します。

`rasa test` は、`DIETClassifier` や `CRFEntityExtractor` のような、トレーニング可能なエンティティ抽出器のみを評価します。`DucklingHTTPExtractor` のような事前学習済みの抽出器は評価されません。

パイプラインに複数のエンティティ抽出器がある場合や、カスタムの抽出器を使用している場合、同じトークンに複数のエンティティが関連付けられることがあります。この場合、テストファイルでリスト表記を使用できます。例：

```yaml
stories:
- story: A basic test story with multiple entities for a single token
  steps:
    - user: |
        I like [ice cream][{\"entity\": \"food\"}, {\"entity\": \"desert\"}]
      intent: inform
    # ...
```

>[!caution]
>いずれかのエンティティのアノテーションに誤りがあると、評価が失敗する可能性があります。よくある問題は、エンティティがトークン内で開始または終了していないことです。例えば、`[Brian](name)'s house` のような `name` エンティティの例がある場合、これはお使いのトークナイザが `Brian's` を複数のトークンに分割する場合にのみ有効です。

### 対話モデルの評価

テストスクリプトを使用して、一連のテストストーリーでトレーニング済みの対話モデルを評価できます：

```
rasa test core --stories test_stories.yml --out results
```

これにより、失敗したすべてのストーリーが `results/failed_test_stories.yml` に出力されます。少なくとも1つのアクション予測が誤っている場合、ストーリーは失敗と見なされます。

テストスクリプトはまた、`results/story_confmat.pdf` という名前で混同行列を保存します。ドメイン内の各アクションについて、混同行列はそのアクションがどれくらいの頻度で正しく予測され、また誤って予測されたかを示します。

#### 生成された警告の解釈

テストスクリプトは、`results/stories_with_warnings.yml` という警告ファイルも生成します。このファイルには、いずれかの対話ターンで [`action_unlikely_intent`](https://legacy-docs-oss.rasa.com/docs/rasa/default-actions#action_unlikely_intent) が予測されたものの、元のストーリーのすべてのアクションは正しく予測された、というテストケースに該当するすべてのストーリーが含まれます。しかし、テストストーリーが元々 `action_unlikely_intent` を含んでいた場合（例えば、[`action_unlikely_intent` の後に特定の対話パスをトリガーするようにルールが設計されていることを確認するため](https://legacy-docs-oss.rasa.com/docs/rasa/default-actions#customization-1)）、しかしポリシーの集合がそれを実行できなかった場合、対応するストーリーは失敗したストーリーとして `results/failed_test_stories.yml` に記録されます。

これらのストーリーは、`action_unlikely_intent` 予測の重大度に基づいてソートされます。この重大度は、[`UnexpecTEDIntentPolicy`](https://legacy-docs-oss.rasa.com/docs/rasa/policies#unexpected-intent-policy) が予測時に自己計算します。重大度が高いほど、そのインテントが実現する可能性は低くなり、したがって特定の対話パスをレビューすることがより重要になります。

注意点として、`action_unlikely_intent` は `UnexpecTEDIntentPolicy` の基盤となる機械学習ベースのモデルによって生成されるため、偽陽性（誤検知）を引き起こす可能性もあります。これらのストーリーの対話パスが既にトレーニングストーリーに存在する場合、そのような警告は無視しても構いません。

#### ポリシー設定の比較

対話モデルの設定を選択したり、特定のポリシーのハイパーパラメータを選択したりするには、対話モデルが未知の対話に対してどれだけ汎化できるかを測定する必要があります。特にプロジェクトの初期段階で、ロボットをトレーニングするための実際の対話データがまだ少ない場合、一部の対話をテストセットとして除外したくないかもしれません。

Rasaには、ポリシー設定の選択と微調整を支援するスクリプトがいくつかあります。設定に満足したら、完全なデータセットで最終的な設定をトレーニングできます。

そのためには、まず異なる設定でモデルをトレーニングする必要があります。比較したいポリシーを含む2つ（またはそれ以上）の設定ファイルを作成し、それらをトレーニングスクリプトに渡してモデルをトレーニングします：

```
rasa train core -c config_1.yml config_2.yml \
  --out comparison_models --runs 3 --percentages 0 5 25 50 70 95
```

[NLUモデルの評価](https://legacy-docs-oss.rasa.com/docs/rasa/testing-your-assistant#comparing-nlu-pipelines)と同様に、上記のコマンドは複数の設定と異なる量のトレーニングデータで対話モデルをトレーニングします。提供された各設定ファイルに対して、Rasaはそれぞれ0%、5%、25%、50%、70%、95%のトレーニングストーリー（トレーニングデータから除外）を使用して対話モデルをトレーニングします。この操作は、結果の一貫性を確保するために3回繰り返されます。

このスクリプトが完了したら、複数のモデルをテストスクリプトに渡して、先ほどトレーニングしたモデルを比較できます：

```
rasa test core -m comparison_models --stories stories_folder \
  --out comparison_results --evaluate-model-directory
```

これにより、`stories_folder` 内のストーリー（トレーニングセットまたはテストセットのいずれか）について各モデルが評価され、どのポリシーが最もパフォーマンスが良いかを示すグラフがいくつか描画されます。前のトレーニングコマンドが各モデルのトレーニングに一定量のトレーニングデータを除外したため、上記のテストコマンドは、モデルが保持されたストーリーに対してどれだけうまく予測できるかを測定できます。個々のポリシーを比較するには、それぞれ1つのポリシーのみを含む設定ファイルを作成します。

>[!note]
>このトレーニングプロセスは非常に時間がかかる可能性があるため、中断されないバックグラウンドのどこかで実行させることをお勧めします。

#### リンク

https://legacy-docs-oss.rasa.com/docs/rasa/testing-your-assistant/
