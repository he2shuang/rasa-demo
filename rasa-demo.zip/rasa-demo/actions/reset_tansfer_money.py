from typing import Any, Text, Dict, List

from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.events import SlotSet
from rasa_sdk.events import AllSlotsReset

class ActionResetTansferMoney(Action):

    def name(self) -> Text:
        return "action_reset_transfer_money"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        # 重置转账流程相关的槽位
        return [
            SlotSet("amount", None),
            SlotSet("final_confirmation", None),
            SlotSet("has_sufficient_funds", None)
        ]


class ActionResetTransferState(Action):
    def name(self) -> Text:
        return "action_reset_transfer_state"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        return [AllSlotsReset()]

class ActionCompleteAndResetTransfer(Action):
    def name(self) -> Text:
        return "action_complete_and_reset_transfer"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        # 第一步：说出成功转账的消息
        dispatcher.utter_message(response="utter_transfer_money_complete")

        # 第二步：返回重置所有槽位的事件
        return [AllSlotsReset()]

# class ActionStopTransfer(Action):
#     def name(self) -> Text:
#         return "action_stop_transfer"

#     def run(self, dispatcher: CollectingDispatcher,
#             tracker: Tracker,
#             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

#         # 获取用户输入的intent，如果是affirm，就停止业务，重置slot；否则就继续