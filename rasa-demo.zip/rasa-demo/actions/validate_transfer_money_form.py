import re
from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker, FormValidationAction
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.types import DomainDict

class ValidateTransferMoneyForm(FormValidationAction):
    """このクラスは送金フォームのカスタムロジックをすべて処理します。"""

    def name(self) -> Text:
        """このバリデーションアクションに一意の名前を付けます。"""
        return "validate_transfer_money_form"

    async def required_slots(  
        self,
        domain_slots: List[Text],
        dispatcher: "CollectingDispatcher",
        tracker: "Tracker",
        domain: "DomainDict",
    ) -> List[Text]:
        """次にどのスロットを埋める必要があるかを動的に決定します。"""
        
        # このメソッドのロジックは簡素化できます。なぜなら、どちらのスロットも必要だからです。
        # しかし、そのままでも問題ありません。
        recipient = tracker.get_slot("recipient")
        amount = tracker.get_slot("amount")

        if amount and not recipient:
            return ["recipient", "amount"]

        return ["recipient", "amount"]

    def validate_recipient(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: DomainDict,
    ) -> Dict[Text, Any]:
        """受取人情報を検証します。"""
        
        # 最新のユーザー入力からエンティティを優先的に検索します。
        recipient_entity = next(tracker.get_latest_entity_values("recipient"), None)

        # 新しいエンティティが見つかった場合は、それを使用してスロットを更新します。
        if recipient_entity:
            # ここで、受取人が連絡先リストにいるかどうかをチェックするなど、より複雑な検証ロジックを追加できます。
            return {"recipient": recipient_entity}
        
        # 新しいエンティティが見つからず、スロットに既に値がある場合（以前の対話から）、その値を維持します。
        # slot_valueはRasaが埋めようとする値であり、tracker.get_slot("recipient")をチェックすることもできます。
        if tracker.get_slot("recipient"):
             return {"recipient": tracker.get_slot("recipient")}

        # 新しいエンティティがなく、スロットも空の場合、ユーザーに質問する必要があります。
        # dispatcher.utter_message(text="どなたに送金しますか？") # Rasaが自動的に質問するため、通常は手動で送信する必要はありません。
        return {"recipient": None} # Noneを返すと検証が失敗したことになり、Rasaが再度質問します。

    def validate_amount(
        self,
        slot_value: Any,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: DomainDict,
    ) -> Dict[Text, Any]:
        """金額情報を検証し、ユーザーによる修正を許可します。"""
        
        # 同様に、最新のユーザー入力からエンティティを優先的に検索します。
        amount_entity = next(tracker.get_latest_entity_values("amount"), None)
        
        # 最新のメッセージで金額エンティティが見つかった場合、この新しい値を処理します。
        if amount_entity:
            match = re.search(r"([\d,.]+)", str(amount_entity))
            if match:
                number_str = match.group(1).replace(',', '')
                try:
                    amount_value = float(number_str)
                    # 検証を追加：金額が正の数であることを確認します。
                    if amount_value >= 0:
                        # 検証に成功した場合、新しい値を含む辞書を返してスロットを更新します。
                        return {"amount": amount_value}
                    else:
                        # 金額が無効です。
                        dispatcher.utter_message(text=f"振込金額は必ず正の数でなければなりません、『{amount_entity}』ではいけません。")
                        return {"amount": None} # 検証失敗
                except ValueError:
                    # 変換失敗
                    dispatcher.utter_message(text=f"申し訳ありませんが、『{amount_entity}』という金額を認識できません。")
                    return {"amount": None} # 検証失敗
            else:
                dispatcher.utter_message(text=f"申し訳ありませんが、『{amount_entity}』から有効な数値を抽出できませんでした。")
                return {"amount": None}

        # 最新の入力に金額エンティティがなく、スロットに既に値がある場合は、元の値を維持します。
        # これにより、ユーザーが他の情報（受取人など）を提供したときに、既存の金額が誤ってクリアされるのを防ぎます。
        if tracker.get_slot("amount"):
            return {"amount": tracker.get_slot("amount")}

        # 新しいエンティティがなく、スロットも空の場合、検証は失敗し、Rasaが再度質問します。
        return {"amount": None}