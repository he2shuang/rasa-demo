# actions/actions.py

from typing import Any, Text, Dict, List

from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.events import SessionStarted, ActionExecuted

# 关键：从rasa_sdk.events导入FollowupAction
from rasa_sdk.events import FollowupAction

class ActionSessionStart(Action):
    """
    一个自定义动作，用于在会话开始时主动发送欢迎消息。
    """

    def name(self) -> Text:
        return "action_session_start"

    def run(
        self,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> List[Dict[Text, Any]]:

        # 1. 创建会话开始事件
        events = [SessionStarted()]

        # 2. 发送你的欢迎消息
        #    确保你在 domain.yml 中定义了 "utter_greet_and_ask" 这个response
        dispatcher.utter_message(template="utter_greet_and_ask")

        # 3. （重要！）添加一个 FollowupAction("action_listen")
        #    这告诉 Rasa 在说完欢迎语后，应该立即进入监听状态，等待用户的输入。
        #    如果没有这一步，Rasa会尝试预测下一个动作，可能导致意外行为。
        events.append(FollowupAction("action_listen"))

        return events
