---
id: jupyter-notebooks
sidebar_label: Jupyter Notebooks
title: Jupyter Notebooks
description: Learn how to integrate open source chatbot platform Rasa into Jupyter notebooks, alongside all your machine learning code.
---

This page contains the most important methods for using Rasa in a Jupyter notebook.

Running asynchronous Rasa code in Jupyter Notebooks requires an extra requirement,
since Jupyter Notebooks already run on event loops. Install this requirement in
the command line before launching jupyter:

```bash
pip3 install nest_asyncio
```

Then in the first cell of your notebook, include:

```bash
import nest_asyncio

nest_asyncio.apply()
print("Event loop ready.")
```
First, you need to create a project if you don't already have one.
To do this, run this cell, which will create the `test-project` directory and make it
your working directory:

```bash
from rasa.cli.scaffold import create_initial_project
import os

project = "test-project"
create_initial_project(project)

# move into project directory and show files
os.chdir(project)
print(os.listdir("."))
```
To train a model, you will have to tell the `train` function
where to find the relevant files.
To define variables that contain these paths, run:

```bash
config = "config.yml"
training_files = "data/"
domain = "domain.yml"
output = "models/"
print(config, training_files, domain, output)
```
## Train a Model

Now we can train a model by passing in the paths to the `rasa.train` function.
Note that the training files are passed as a list.
When training has finished, `rasa.train` returns the path where the trained model has been saved.

```bash
import rasa

model_path = rasa.train(domain, config, [training_files], output)
print(model_path)
```
## Chat with your assistant

To start chatting to an assistant, call the `chat` function, passing
in the path to your saved model. If you do not have custom actions you can set `endpoints = None` or omit it:

```bash
from rasa.jupyter import chat

endpoints = "endpoints.yml"
chat(model_path, endpoints)
```
## Evaluate your model against test data

Rasa has a convenience function for getting your training data.
Rasa's `get_core_directory` and `get_nlu_directory` are functions which
recursively find all the stories or NLU data files
and copies them into temporary directories.
The return values are the paths to these newly created directories.

```bash
import rasa.shared.data as data
nlu_data_directory = data.get_nlu_directory(training_files)
stories_directory = data.get_core_directory(training_files)
print(stories_directory, nlu_data_directory)
```
To test your model, call the `test` function, passing in the path
to your saved model and directories containing the stories and nlu data
to evaluate on.

```bash
rasa.test(model_path, stories_directory, nlu_data_directory)
print("Done testing.")
```
The results of the core evaluation will be written to a file called `results`.
NLU errors will be reported to `errors.json`.
Together, they contain information about the accuracy of your model's
predictions and other metrics.

```bash
if os.path.isfile("errors.json"):
    print("NLU Errors:")
    print(open("errors.json").read())
else:
    print("No NLU errors.")

if os.path.isdir("results"):
      print("\n")
      print("Core Errors:")
      print(open("results/failed_test_stories.yml").read())
```
