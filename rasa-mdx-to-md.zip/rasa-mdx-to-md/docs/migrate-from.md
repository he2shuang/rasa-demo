---
id: migrate-from
sidebar_label: Migrate From (beta)
title: Migrate From Other Tools (beta)
---

Here are a few reasons why we see developers switching from other tools to Rasa:

* **Faster**: Runs locally - no HTTP requests or server round trips required

* **Customizable**: Tune models and get higher accuracy with your data set

* **Open source**: No risk of vendor lock-in - Rasa is under the Apache 2.0 license and you can  use it in commercial projects

In addition, our open source tools allow developers to build contextual AI assistants and manage dialogues  with machine learning instead of rules - check it out in <a className="reference external" href="http://blog.rasa.com/a-new-approach-to-conversational-software/" target="_blank">this blog post</a>.

Learn how to migrate from:

* [Google Dialogflow](./migrate-from/google-dialogflow-to-rasa.md)

* [Wit.ai](./migrate-from/facebook-wit-ai-to-rasa.md)

* [Microsoft LUIS](./migrate-from/microsoft-luis-to-rasa.md)

* [IBM Watson](./migrate-from/ibm-watson-to-rasa.md)