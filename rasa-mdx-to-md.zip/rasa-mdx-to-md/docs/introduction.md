---
slug: /
sidebar_label: Introduction
title: Introduction to Rasa Open Source & Rasa Pro
hide_table_of_contents: true
description: Learn more about open-source natural language processing library Rasa for conversation handling, intent classification and entity extraction in on premise chatbots.
---


With over 25 million downloads, Rasa Open Source is the most popular open source framework for building chat and voice-based AI assistants.

Rasa Pro is an open core product powered by open source conversational AI framework with additional analytics, security, and observability capabilities.

Rasa Pro is a part of our enterprise solution, Rasa Platform. Another product that makes up of Rasa Platform is Rasa X/Enterprise.
It is our low-code user interface that supports conversational AI Teams reviewing and improving AI Assistants at scale. It must be used with Rasa Pro.
To learn more about Rasa X/Enterprise, see the [Rasa X/Enterprise documentation](https://rasa.com/docs/rasa-enterprise).

You can also learn more about our release and maintenance policy on [Rasa Product Release and Maintenance Policy](https://rasa.com/rasa-product-release-and-maintenance-policy/).

![[static/img/introduction.png]]

## Rasa Open Source

Rasa Open Source is an open source conversational AI platform that allows you to understand and hold conversations, and connect to messaging channels and third party systems through a set of APIs. It supplies the building blocks for creating virtual (digital) assistants or chatbots.


## Rasa Pro

> [!warning] Rasa Pro Only
> 

Rasa Pro is the commercial, pro-code offering of Rasa that’s built to address enterprise needs around security, observability and scale. [Read more here](./rasa-pro.md).

When the content is only applicable to Rasa Pro, you will see the below label:

This means you need to have a Rasa Pro License in order to access the capabilities detailed in that section.
