---
id: ibm-watson-to-rasa
sidebar_label: Rasa as open source alternative to IBM Watson - Migration Tips
title: Rasa as open source alternative to IBM Watson - Migration Tips
description: Open source alternative to IBM Watson for conversational bots and NLP
---

There is no support for IBM Watson yet. However, a group of community members is working on a way
to use <a className="reference external" href="https://developer.ibm.com/tutorials/learn-how-to-export-import-a-watson-assistant-workspace/" target="_blank">exported IBM Watson workspaces</a>
in Rasa. If you're interested in that, check out our <a className="reference external" href="https://forum.rasa.com/" target="_blank">Community Forum</a>.
