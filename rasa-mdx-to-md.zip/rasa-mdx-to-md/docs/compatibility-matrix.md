---
id: compatibility-matrix
sidebar_label: Compatibility Matrix
title: Compatibility Matrix
description: |
  Information about compatibility between Rasa Pro Services and Rasa Plus.
---


When choosing a version of Rasa Pro Services to [deploy](./deploy/deploy-rasa-pro-services.md), you can refer to the
table below to see which one is compatible with your installation of Rasa Plus.

Rasa Pro Services version is independent of Rasa Plus version, except that they share the same major version number.


| Rasa Pro Services |  Rasa Plus          |
|------------------:|--------------------:|
| 3.0.x             | 3.3.x, 3.4.x, 3.5.x |
| 3.1.x             | 3.6.x               |
