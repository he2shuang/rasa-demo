---
id: rasa-pro
sidebar_label: Rasa Pro
title: Rasa Pro
hide_table_of_contents: true
---

Rasa Pro is the commercial, pro-code offering of Rasa built to address enterprise needs
around security, observability and scale.

Rasa Pro integrates seamlessly with enterprise technology stacks and is the recommended platform
for all Rasa enterprise customers.
To read more about installing Rasa Pro, click [here](./installation/rasa-pro/installation.md).

## Rasa Pro Features

### Analytics with Conversational Data Pipeline

Visualise Rasa metrics in a third-party tool to measure the performance of your assistant.

[Read more here](./monitoring/analytics/getting-started-with-analytics.md).

### Concurrent Lock Store

Scale deployment and reliably handle high volumes of traffic across multiple Rasa instances with the confidence that no messages will be dropped.

[Read more here](./lock-stores.md#concurrentredislockstore).

### End-to-End Testing

Test your assistant with our end-to-end testing solution designed to meet enterprise-grade integration and acceptance testing criteria.

[[./testing-your-assistant.md#End-To-End Testing|Read more here]].

### IVR Voice Connector

Integrate with best-in-class IVR systems through our OOTB voice connectors.

[Read more here](./connectors/audioodes-voiceai-connect.md).

### Observability (Tracing)

Resolve performance issues faster and identify bottlenecks in message handling and model training.

[Read more here](./monitoring/tracing.md).

### PII Handling

Anonymize PII (Personal Identifiable Information) in logs and events streamed via the Kafka event broker. 

[Read more here](./pii-management.md)

### Real-Time Markers

Mark points of interest in conversations to support the targeted analysis of user journeys real time.

[Read more here](./monitoring/analytics/realtime-markers.md)

### Secrets Management

Enhance security with our seamless Vault integration, enabling dynamic credential rotation for Rasa databases without system disruptions.

[Read more here](./secrets-managers.md).

### Security Scanning for Vulnerability Protection

Nightly and proactive security patches on your docker image to make sure dependencies are always up to date.

### Spaces (Alpha Release)

Modularize your assistant for better scaling and team collaboration.

[Read more here](./spaces.md)
