---
id: cisco-webex-teams
sidebar_label: Cisco Webex Teams
title: Cisco Webex Teams
description: Build a Rasa Chat Bot on Cisco Webex
---

You first have to create a cisco webex app to get credentials.
Once you have them you can add these to your `credentials.yml`.

## Getting Credentials

**How to get the Cisco Webex Teams credentials:**

You need to set up a bot. Check out the [Cisco Webex for Developers documentation](https://developer.webex.com/docs/bots) for information
about how to create your bot.

After you have created the bot through Cisco Webex Teams, you need to create a
room in Cisco Webex Teams. Then add the bot in the room the same way you would
add a person in the room.

You need to note down the room ID for the room you created. This room ID will
be used in `room` variable in the `credentials.yml` file.

Please follow this link below to find the room ID
`https://developer.webex.com/endpoint-rooms-get.html`

In the OAuth & Permissions section, add the URL of the Rasa endpoint
that Webex should forward the messages to. The endpoint for receiving Cisco Webex Teams messages
is `http://<host>:<port>/webhooks/webexteams/webhook`, replacing
the host and port with the appropriate values from your running Rasa server.

## Running on Cisco Webex Teams

Add the Webex Teams credentials to your `credentials.yml`:

```yaml-rasa
webexteams:
  access_token: "YOUR-BOT-ACCESS-TOKEN"
  room: "YOUR-CISCOWEBEXTEAMS-ROOM-ID"
```


Restart your Rasa server
to make the new channel endpoint available for Cisco Webex Teams to send messages to.


>[!note] note
>If you do not set the `room` keyword argument, messages will by delivered back to
the user who sent them.
