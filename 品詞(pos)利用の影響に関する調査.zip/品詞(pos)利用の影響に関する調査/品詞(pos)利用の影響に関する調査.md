
### NLU Pipelineにおける設定

`config`ファイルを2つのバージョンで設定します。両者の唯一の違いは、`NLU Pipeline`の設定において`LexicalSyntacticFeaturizer`で`pos`（品詞）特徴を使用するかどうかです。

###### posを使用しない設定 `config_raw.yml`

```
recipe: default.v1
assistant_id: placeholder_default

language: ja

pipeline:
- name: "SpacyNLP"
  model: 'ja_ginza'
- name: "SpacyTokenizer"
- name: "SpacyFeaturizer"
- name: DIETClassifier
  epochs: 100
  
policies:
  - name: MemoizationPolicy
  - name: RulePolicy
  - name: TEDPolicy
    max_history: 5
    epochs: 100
    constrain_similarities: true
```

###### posを使用する設定 `config_pos.yml`

```
recipe: default.v1
assistant_id: placeholder_default

language: ja

pipeline:
- name: "SpacyNLP"
  model: 'ja_ginza'
- name: "SpacyTokenizer"
- name: "SpacyFeaturizer"
- name: LexicalSyntacticFeaturizer
  features:
  - ["pos"]
- name: DIETClassifier
  epochs: 100
  
policies:
  - name: MemoizationPolicy
  - name: RulePolicy
  - name: TEDPolicy
    max_history: 5
    epochs: 100
    constrain_similarities: true
```

### NLU学習データの設定

学習データを2つのバージョンで設定します。両者の唯一の違いは、学習データに中国語の人名が含まれているかどうかです。

###### 学習エンティティは`recipient`のみで、日本語の人名のみを含むデータ `./data_raw/nlu.yml`

```
- intent: transfer_money
  examples: |
    - [山田 太郎](recipient)さんにお金を送りたいです。
    - [铃木 美咲](recipient)さんに送金したいです。
    - [高桥 真奈美](recipient)さんへ振込をしたいです。
    - [佐藤 良太郎](recipient)さんに振込したいです。
    - [铃木 香织](recipient)さんに資金を送付したいです。
    - [铃木 一郎](recipient)さんに送金したく思っています。
      
- intent: affirm
  examples: |
    - はい
    - ええ
    - もちろん
    - それは良さそう
    - 正しい
- intent: deny
  examples: |
    - いいえ
    - いや
    - そんなことはありません
    - そう思いません
    - それは嫌いです
    - あり得ません
    - 本当じゃない
```

###### 学習エンティティは`recipient`のみで、中国語の人名を追加したデータ `./data_plus/nlu.yml`

```
- intent: transfer_money
  examples: |
    - [山田 太郎](recipient)さんにお金を送りたいです。
    - [铃木 美咲](recipient)さんに送金したいです。
    - [高桥 真奈美](recipient)さんへ振込をしたいです。
    - [佐藤 良太郎](recipient)さんに振込したいです。
    - [铃木 香织](recipient)さんに資金を送付したいです。
    - [铃木 一郎](recipient)さんに送金したく思っています。
    - [羅 楊](recipient)さんに送金する。
    - [李 蒙](recipient)さんに送金したいですと思います。
    - [盧 涛](recipient)さんに振り込みたいと思います。
    - [張 裕](recipient)さんに資金を送付したいです。
    - [李周楠](recipient)さんに資金を送付したいです。
    - [牛思源](recipient)さんに資金を送付したいです。
- intent: affirm
  examples: |
    - はい
    - ええ
    - もちろん
    - それは良さそう
    - 正しい
- intent: deny
  examples: |
    - いいえ
    - いや
    - そんなことはありません
    - そう思いません
    - それは嫌いです
    - あり得ません
    - 本当じゃない
```

### テストケース

NLUの学習データに対し、以下のテストケースを設定します。テストはそれぞれ「日本語」「英語」「中国語」「数字」の4つの観点から行います。

```
木村 光一さんに送金したいです。

潘智さんに送金したいです。

Jimに送金したいです。

100に送金したいです。
```

### テスト結果

異なるNLUデータ（中国語の人名を含むか否か）に対し、それぞれ`pos`特徴の有無に基づいてモデルを学習させます。これにより合計4つのモデルが作成されます。各モデルにおけるテストの全データは以下の通りです。  
[[raw_data#models/nlu_data_raw_config_raw|`models/nlu_data_raw_config_raw`]]
[[raw_data#models/nlu_data_raw_config_pos|`models/nlu_data_raw_config_pos`]]
[[raw_data#models/nlu_data_plus_config_raw|`models/nlu_data_plus_config_raw`]]
[[raw_data#models/nlu_data_plus_config_pos|`models/nlu_data_plus_config_pos`]]

4つのモデルで同一のテストケースを実行し、実験結果を以下にまとめます。

##### 用語解説
`confidence`（信頼度）は、モデルが予測結果に対して持つ「自信の度合い」を定量的に表す指標です。
- 0から1の間の浮動小数点数です。
- モデルが「ユーザーが入力したこの文が、予測されたこの意図に属する」と推定する確率を表します。

##### シナリオ1：テストケースで日本語の人名を使用

テストケース：
```
木村 光一さんに送金したいです。
```

「ginza」処理後、pos属性を含むトークンが生成された。

![[Pasted image 20251021133834.png|500]]

|                     | posを使用しない場合                          | posを使用する場合                           |
| ------------------- | ------------------------------------ | ------------------------------------ |
| **学習データで日本語の人名のみ**  | ![[Pasted image 20251020105144.png]] | ![[Pasted image 20251020105429.png]] |
| **学習データで中国語の人名を含む** | ![[Pasted image 20251020105729.png]] | ![[Pasted image 20251020110026.png]] |


日本語の人名を使用したテストケースでは、全てのモデルが`木村 光一`をエンティティとして正確に抽出できました。`pos`を使用したモデルはエンティティを抽出する際の信頼度が高いです。

##### シナリオ2：テストケースで中国語の人名を使用

テストケース：

```
潘智さんに送金したいです。
```

「ginza」処理後、pos属性を含むトークンが生成された。

![[Pasted image 20251021134959.png|500]]

|                     | posを使用しない場合                          | posを使用する場合                           |
| ------------------- | ------------------------------------ | ------------------------------------ |
| **学習データで日本語の人名のみ**  | ![[Pasted image 20251020143711.png]] | ![[Pasted image 20251020143107.png]] |
| **学習データで中国語の人名を含む** | ![[Pasted image 20251020142426.png]] | ![[Pasted image 20251020141801.png]] |

中国語の人名を使用したテストケースでは、全てのモデルが`潘智`をエンティティとして正確に抽出できました。`pos`を使用したモデルはエンティティを抽出する際の信頼度が高いです。


##### シナリオ3：テストケースで英語の人名を使用

テストケース：

```
Jimに送金したいです。
```

「ginza」処理後、pos属性を含むトークンが生成された。

![[Pasted image 20251021134904.png|500]]

|                     | posを使用しない場合                          | posを使用する場合                           |
| ------------------- | ------------------------------------ | ------------------------------------ |
| **学習データで日本語の人名のみ**  | ![[Pasted image 20251020105231.png]] | ![[Pasted image 20251020105530.png]] |
| **学習データで中国語の人名を含む** | ![[Pasted image 20251020105849.png]] | ![[Pasted image 20251020110105.png]] |


英語の人名を使用したテストケースでは、`pos`を使用したモデルは`Jim`をエンティティとして正確に抽出できました。一方、`pos`を使用しないモデルは、学習データに英語の人名が含まれていないため、`Jim`をエンティティとして認識できませんでした。

##### シナリオ4：テストケースで数字を使用

テストケース：

```
100に送金したいです。
```

「ginza」処理後、pos属性を含むトークンが生成された。

![[Pasted image 20251021112304.png|500]]

|                     | posを使用しない場合                          | posを使用する場合                           |
| ------------------- | ------------------------------------ | ------------------------------------ |
| **学習データで日本語の人名のみ**  | ![[Pasted image 20251020105249.png]] | ![[Pasted image 20251020105549.png]] |
| **学習データで中国語の人名を含む** | ![[Pasted image 20251020105904.png]] | ![[Pasted image 20251020110119.png]] |

数字を人為的に誤って入力したテストケースでは、どのモデルも誤った`100`をエンティティとして抽出することはありません。

### 実験結果一覧

各モデルが異なるテストケースでエンティティを識別した信頼度は以下の表にまとめられています。

|                      | POSを使用しない、学習データで日本語の人名のみ | POSを使用しない、学習データで中国語の人名を含む | POSを使用し、学習データで日本語の人名のみ | POSを使用し、学習データで中国語の人名を含む |
| -------------------- | ------------------------ | ------------------------- | ---------------------- | ----------------------- |
| **テストケースで日本語の人名を使用** | 0.66133                  | 0.82952                   | 0.99641                | 0.97476                 |
| **テストケースで中国語の人名を使用** | 0.47046                  | 0.69467                   | 0.97216                | 0.99402                 |
| **テストケースで英語の人名を使用**  | 識別されない                   | 識別されない                    | 0.46015                | 0.79767                 |
| **テストケースで数字を使用**     | 識別されない                   | 識別されない                    | 識別されない                 | 識別されない                  |



