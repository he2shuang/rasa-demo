`SpacyTokenizer`で`ja_ginza`モデルを使用すると、得られるトークンには`pos`（品詞）属性が含まれます。この属性を活用することで、インテントとエンティティの抽出に良い影響を与える可能性があります。本稿では、`LexicalSyntacticFeaturizer`で`pos`属性を使用することがインテントとエンティティの抽出性能に影響を与えるかを、比較実験を通じて検証します。

![[Pasted image 20251014125011.png]]

### **2つの異なる設定ファイルを作成**

以下の2つの設定ファイルの違いは1点のみです。`LexicalSyntacticFeaturizer`の`features`パラメータにおいて、`config_optimized.yml`には`config_base.yml`にはない`pos`が追加されています。

##### `config_base.yml`
```
recipe: default.v1

assistant_id: ***

language: ja

pipeline:
- name: "SpacyNLP"
  model: 'ja_ginza'
- name: "SpacyTokenizer"
- name: "SpacyFeaturizer"
- name: LexicalSyntacticFeaturizer
  features:
    - ["BOS", "EOS", "digit"]
- name: CountVectorsFeaturizer
- name: CountVectorsFeaturizer
  analyzer: char_wb
  min_ngram: 1
  max_ngram: 4
- name: DIETClassifier
  epochs: 100

policies:
  - name: MemoizationPolicy
  - name: RulePolicy
  - name: TEDPolicy
    max_history: 5
    epochs: 100
    constrain_similarities: true
```

##### `config_optimized.yml`
```
recipe: default.v1

assistant_id: ***

language: ja

pipeline:
- name: "SpacyNLP"
  model: 'ja_ginza'
- name: "SpacyTokenizer"
- name: "SpacyFeaturizer"
- name: LexicalSyntacticFeaturizer
  features:
    - ["BOS", "EOS", "pos", "digit"]
- name: CountVectorsFeaturizer
- name: CountVectorsFeaturizer
  analyzer: char_wb
  min_ngram: 1
  max_ngram: 4
- name: DIETClassifier
  epochs: 100

policies:
  - name: MemoizationPolicy
  - name: RulePolicy
  - name: TEDPolicy
    max_history: 5
    epochs: 100
    constrain_similarities: true
```

### **元の学習データ**
```
version: "3.1"
nlu:

- intent: affirm
  examples: |
    - はい
    - ええ
    - もちろん
    - それは良さそう
    - 正しい

- intent: deny
  examples: |
    - いいえ
    - いや
    - そんなことはありません
    - そう思いません
    - それは嫌いです
    - あり得ません
    - 本当じゃない

- intent: transfer_money
  examples: |
    - お金を送金したいです
    - 友達にお金を送金したい
    - 家族にお金を送金したい
    - 誰かにお金を送ってください
    - お金を渡してください
    - [100](amount)ドルを[中島](recipient)に送金したい
    - [小山](recipient)にお金を送れますか
    - [50](amount)を送金してください
    - お金を送りたいです
    - [山本](recipient)に[699](amount)円を送金したいです。
    - [山本](recipient)に[699](amount)円を送金したいですと思います。
    - [山本さん](recipient)に[699](amount)円を振り込みたいと思います。
  
- intent: inform
  examples: |
    - [limeng](recipient)
    - [895](amount)
    - [David](recipient)に送ってください
    - [789](amount)
    - [長嶋](recipient)
    - [田中さん](recipient)
    - [山田さん](recipient)
    - [小野さん](recipient)
    - [234](amount)円
    - [2239](amount)元

- intent: cancel_transfers
  examples: |
    - キャンセルしたいです
    - お金の送金をキャンセルします
    - もういいです、送金しません
    - キャンセル
    - 停止
    - stop
    - cancel
    - キャンセルしたいです
    - 送金をキャンセルします
    - いいえ、やめておきます

- intent: retry_transfer
  examples: |
    - いいよ、もう一度やってみたい
    - うーん、金額を変えてみる
    - 別の方法を試す
    - それでいい
    - はい、修正して
    - もちろん
    - 修正して
```

### **テスト用の新規データ**

テストデータ`tests/nlu.yml`の内容は以下の通りです。このテストデータは単純にいくつかの項目を列挙したものであり、テストデータの数やテストの観点が考慮不足かもしれません。

```
version: "3.1"
nlu:

# --- send_money インテントのテスト ---
- intent: send_money
  examples: |
    # ケース1: 未見のエンティティ「佐藤」。これは汎化能力をテストする鍵である。
    - [佐藤](recipient)さんに[五千円](amount)を送りたい
    
    # ケース2: 未見のエンティティ「鈴木」と金額の不同表达「一万円」。
    - [鈴木](recipient)へ[一万円](amount)の送金をお願いします
    
    # ケース3: 異なる文型構造「〜への送金」。文法理解を試す。
    - [渡辺](recipient)さんへの[3000円](amount)の送金は可能ですか？
    
    # ケース4: 実体の順序を逆転させる。
    - [二千円](amount)を[中村](recipient)さんに振り込んでください
    
    # ケース5: 少し口語的でシンプルな表現。
    - [高橋](recipient)に[100円](amount)送って
    
    # ケース6: ユーザーが誤った情報を入力しました
    - 東京に[3000円](amount)を送りたい
    - 東京さんに[3000円](amount)を送りたい
    - 1000に[3000円](amount)を送りたい
    - [山田さん](recipient)に銀座を送金したい
    - 誰かに[3000円](amount)を送りたい

# --- 混同を招く可能性のある文を追加する（ネガティブサンプル）---
- intent: greet
  examples: |
    # ケース7: モデルが挨拶文で意図やエンティティを認識するかどうかを確認する。
    - こんにちは、鈴木さん
    - いつもお世話になっております
```

### **検証プロセス**

参考リンク：[Testing Your Assistant](https://legacy-docs-oss.rasa.com/docs/rasa/testing-your-assistant/#interpreting-the-output)

##### **設定ファイルごとにモデルを学習**

```
rasa train nlu --config config_base.yml --out models/nlu_base

rasa train nlu --config config_optimized.yml --out models/nlu_optimized

```

##### **学習済みモデルで同じテストケースを評価**

```

rasa test nlu --model models/nlu_base --nlu tests/nlu.yml --out results/base_results

rasa test nlu --model models/nlu_optimized --nlu tests/nlu.yml --out results/optimized_results

```


### **テスト結果**

##### **全体的な比較**

**結果から、エンティティ「recipient」の認識において、「pos」を設定したテスト結果の方が、設定しない場合よりも優れていることがわかります。精度（Precision）がほぼ同等である中、再現率（Recall）とF1スコアがより高くなっています。**（下図の右側が「pos」を設定したテスト結果です）  
![[Pasted image 20251014124435.png]]

**精度 ([precision](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.precision_score.html))**: モデルが正と予測したサンプルのうち、実際に正であったサンプルの割合。高い精度は、モデルの予測結果の信頼性が高いこと、すなわち**偽陽性（False Positive）率が低い**ことを意味します。  
**再現率 ([recall](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.recall_score.html))**: 実際に正であるサンプルのうち、モデルが正しく正と予測できたサンプルの割合。高い再現率は、モデルが関連インスタンスを網羅的に検出できていること、すなわち**偽陰性（False Negative）率が低い**ことを意味します。  
**誤認識（confused_with）**: モデルが `recipient` をどの他のエンティティと誤って認識したかを示します。  
**サポート数（support）**: テストデータセット内で、そのエンティティが合計で何回出現したかを示します。  
**F1スコア ([f1-score](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.f1_score.html))**: 精度と再現率の調和平均であり、モデルの総合的な性能評価に用いられます。精度と再現率のバランスを取る指標であり、両者が共に高い場合に高い値となります。

**マイクロ平均 (`micro avg`):** 全てのカテゴリのTP、FP、FNを合算してから、全体の指標を一度に計算します。  
**マクロ平均 (`macro avg`):** カテゴリごとに指標を計算し、その単純な算術平均を取ります。  
**加重平均 (`weighted avg`):** マクロ平均と同様ですが、各カテゴリのサポート数（サンプル数）に応じて重み付けをして平均を計算します。

##### **個別のケース分析**

テスト文「佐藤さんに五千円を送りたい」において、両設定とも学習データにない「佐藤さん」を認識できていますが、「pos」を設定した場合の方が、信頼度スコア（confidence_entity）が高くなっています。（下図の右側が「pos」を設定したテスト結果です）  
![[Pasted image 20251014121603.png]]

**`"entities": [...]`**: このテキストの**「正解データ」 (Ground Truth)**、つまり正しいラベルを示します。  
**`"predicted_entities": [...]`**: DIETClassifierモデルがこのテキストからエンティティを抽出した**実際の予測結果**です。  
**`confidence_entity`**: モデルが行った**エンティティ分類予測に対する信頼度スコア**を表します。この値が**1.0**に近いほど、モデルがその予測に**非常に自信を持っている**ことを示します。逆に**0**に近いほど、モデルの**確信度が低い**ことを意味し、不確かな推測である可能性があります。

しかし、一部の誤りやすい入力に対しては、「pos」を設定しても、誤った情報を有効なエンティティとして認識してしまうケースが見られました。

例えば、ユーザーが「東京さんに3000円を送りたい」という誤った文を入力した場合、以下のように「さん」だけをエンティティ「recipient」として誤認識してしまいます。  
![[Pasted image 20251014122713.png]]

また、「1000に3000円を送りたい」という誤った文を入力した場合、「amount」エンティティを2つ認識してしまいます。  
![[Pasted image 20251014122852.png]]

上記のような混同しやすい誤入力については、別のアプローチでの対策が必要となるでしょう。

### **結論**

**`LexicalSyntacticFeaturizer`で`pos`（品詞）属性を使用することは、インテントとエンティティの抽出に良い影響を与え、特にエンティティ予測の精度と信頼度を向上させることが確認できました。ただし、その向上には限界があり、一部の混同しやすい誤った入力に対する根本的な解決には至りませんでした。**
